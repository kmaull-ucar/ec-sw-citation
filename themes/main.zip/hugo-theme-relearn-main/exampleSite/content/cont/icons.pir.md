+++
title = "Ay'cons an' logos"
weight = 27
+++
{{< piratify >}}