+++
chapter = true
title = "Shorrrtcodes"
weight = 3
+++
{{< piratify >}}