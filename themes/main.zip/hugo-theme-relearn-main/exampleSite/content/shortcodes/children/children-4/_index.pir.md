+++
alwaysopen = false
descrption = "This be a hidden demo child plank"
hidden = true
tags = ["children", "hidden"]
title = "Plank 4 (hidden)"
weight = 40
+++
{{< piratify >}}