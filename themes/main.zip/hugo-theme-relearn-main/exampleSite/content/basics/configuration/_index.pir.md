+++
title = "Configurrrat'n"
weight = 20
+++
{{< piratify >}}