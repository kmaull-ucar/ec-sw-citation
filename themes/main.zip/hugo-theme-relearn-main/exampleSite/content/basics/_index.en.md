+++
chapter = true
title = "Basics"
weight = 1
+++

### Chapter 1

# Basics

Discover what this Hugo theme is all about and the core-concepts behind it.
