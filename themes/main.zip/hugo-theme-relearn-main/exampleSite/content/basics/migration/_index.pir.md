+++
disableToc = false
title = "Migrrrat'n"
weight = 17
+++
{{< piratify >}}