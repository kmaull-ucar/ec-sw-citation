+++
title = "Relearrrn Theme fer Cap'n Hugo"
+++

{{% notice warning %}}
Arrr fello pirrates, be awarrre some featurrres may not work fer us in this trrranslat'n. Like table of contents orrr seeing Merrrmaids.
{{% /notice %}}

{{< piratify >}}