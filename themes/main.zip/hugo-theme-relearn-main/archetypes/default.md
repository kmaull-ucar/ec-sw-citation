+++
title = "{{ replace .Name "-" " " | title }}"
weight = 5
+++

Lorem Ipsum.